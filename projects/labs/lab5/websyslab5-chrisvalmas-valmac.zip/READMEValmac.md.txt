Chris Valmas    Valmac     Lab5

Part 1.
	Made it so the parent element has the event binder on it saving time for when you click 
	on a list element to make it go away.

Part 2. 
	So what I did was:
1.	Condense the file by using as little lines as I saw acceptable
2.	The background picture is now the same thing but a css color instead of a jpg
3.	Javascript loads after the page loads
4.	CSS is in the header now where it belongs
5.	Deleted all the lists that were made in html because it was unnecessary as 5000 are already being made in the JS

Overall from Part 1 and 2 the file is now 1 kb from 319 kb which helps the page load faster� if the page had more content a drastic cut in data like this would help exponentially. After this lab I can now see just how important having a fully optimized site is for making a good user friendly experience.

Also the lab5start.html is the readable one the lab5.html is the not so readable but final one