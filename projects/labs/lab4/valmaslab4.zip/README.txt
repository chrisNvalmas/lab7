Christopher Valmas Lab 4



Part 1:
	
	Made my JSON file and gave applicable names to the data like; songs, album, genres etc. I made genres an array to store the multiple genres for songs easier.

Part 2:

	The JS file populates the page to match my lab2 output for part 1 of lab2. All I did to the html was delete tags it had as it didn't match my lab2 output and also needed to be deleted so I could put proper tags for items.